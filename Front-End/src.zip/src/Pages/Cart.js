import '../Styles/Page.css';
import '../Styles/about.css';
import ProductCard from '../Components/ProductCard';

// Vegetables page function

function Cart(props) {
    // Return the vegetables page
    const cart = props.cart
    let formatCart = cart.map(function(product){
        return <ProductCard name={product.name} price={product.price} description={product.description} src={product.src} unit={product.unit} cart={props.cart} setCart={props.setCart}/>;
    })
    return (
        <div>
        <h2>My Cart</h2>
        <div className="products">
          {formatCart}
        </div>
      </div>
        
  );
  }
  // Export the vegetables page
  export default Cart;