import React, { useEffect, useState } from 'react';
import '../Styles/product.css';
import '../Styles/Page.css';
import ProductCard from '../Components/ProductCard';
import { getProducts } from '../data/repository';
import { FaShoppingCart, FaPlus, FaMinus, FaTrashAlt, } from 'react-icons/fa';
import { AiFillPlusCircle} from "react-icons/ai";
import { FaSquarePlus } from "react-icons/fa6";
import { FcPlus,FcMinus, FcEmptyTrash } from "react-icons/fc";



function Products(props) {
  const [products, setProducts] = useState([]);
  const [quantities, setQuantities] = useState({});
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await getProducts();
        const fetchedProducts = Object.values(response); // Extract products
        setProducts(fetchedProducts); // Update state with fetched data
      } catch (error) {
        console.error('Error fetching products:', error); // Handle potential errors
      }
    }

    fetchData(); // Call fetchData function when component mounts
  }, []); // Empty dependency array ensures the effect runs only once


  const handleAddToCart = (productId) => {
    setQuantities((prevQuantities) => ({
      ...prevQuantities,
      [productId]: (prevQuantities[productId] || 0) + 1
    }));
  };
  
  
  
  // Function to handle removing a product from the cart
  const handleRemoveFromCart = (productId) => {
    // Decrement quantity by 1, if quantity is greater than 0
    if (quantities[productId] > 0) {
      setQuantities((prevQuantities) => ({
        ...prevQuantities,
        [productId]: prevQuantities[productId] - 1
      }));
    }
  };

  const handleDeleteFromCart = (productId) => {
    // Decrement quantity by 1, if quantity is greater than 0
    const updatedCart = cart.filter(item => item.id !== productId);
    // Update the cart state with the filtered cart
    setCart(updatedCart);
    // If needed, update the quantities object as well
    const updatedQuantities = { ...quantities };
    delete updatedQuantities[productId];
    setQuantities(updatedQuantities);
  };

  // Function to split products into rows
  const splitProductsIntoRows = (products, rowSize) => {
    const rows = [];
    for (let i = 0; i < products.length; i += rowSize) {
      rows.push(products.slice(i, i + rowSize));
    }
    return rows;
  };

  // Function to get selected products
  const getSelectedProducts = () => {
    return products.filter(product => quantities[product.id] > 0);
  };

  return (
    <div className="body">
      <div className="inside_body">
        {/* Main content */}
        <div className="body2">
          <h1 className="product">Our Products</h1>
          {/* Map over the products array to render each row */}
          {splitProductsIntoRows(products, 5).map((row, index) => (
            <div key={index} className="index">
              {/* Map over each row to render products */}
              {row.map((product, productIndex) => (
                <div key={product.id} className="product1">
                  <img src={product.src} alt={product.name} className="image" />
                  <h2 className="product_name">{product.name}</h2>
                  <div class="container">
                    <h3 className="product_price">
                      {product.price.toLocaleString()}
                    </h3>
                  </div>
                  {/* Display quantity buttons if product is in cart */}
                  {quantities[product.id] > 0 ? (
                    <div className="displaybutton">
                      <button
                        onClick={() => handleRemoveFromCart(product.id)}
                        className="minus"
                      >
                        <FcMinus />
                      </button>
                      <span className='productquantity'>
                        {quantities[product.id]}
                      </span>
                      <button
                        onClick={() => handleAddToCart(product.id)}
                        className="plus"
                      >
                        <FcPlus />
                      </button>
                      <button
                        onClick={() => handleDeleteFromCart(product.id)}
                        className="trash"
                      >
                        <FcEmptyTrash />
                      </button>
                    </div>
                  ) : (
                    <button
                      onMouseEnter={(e) => {
                        e.target.style.transform =
                          "scale(1.1)"; /* Scale up on hover */
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.transform =
                          "scale(1)"; /* Scale back to original size on mouse leave */
                      }}
                      onClick={(e) => {
                        handleAddToCart(product.id);
                      }}
                      className="addtocart"
                    >
                      <FaShoppingCart className="shoppingcart" /> Add to Cart{" "}
                      {/* Shopping cart icon */}
                    </button>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
      <div>
        <div className="cart">
          <h2 className="cart1">Cart</h2>

          {getSelectedProducts().map((product, index) => (
  quantities[product.id] > 0 && (
    <div key={product.id} className="selectproduct">
      {/* Product details */}
      <div>
        <div className="cartimage">
          <img
            src={product.src}
            alt={product.name}
            className="cartimage1"
          />
          <span className="cartproduct">
            {product.name} - {quantities[product.id]}
          </span>
        </div>

        {/* Buttons for handling the product */}
        <div className="productbutton">
          <button onClick={() => handleRemoveFromCart(product.id)}>
            <FcMinus />
          </button>
          <button onClick={() => handleAddToCart(product.id)}>
            <AiFillPlusCircle  />
          </button>
          <button onClick={() => handleDeleteFromCart(product.id)}>
            <FcEmptyTrash />
          </button>
        </div>

        {/* Separator */}
        {index < getSelectedProducts().length - 1 && <hr />}
      </div>
    </div>
  )
))}


        </div>
      </div>
    </div>
  );
}

export default Products;
