import '../Styles/footer.css';

// Footer function
function Footer (){
    // Return the footer
    return (
      <div class="footer">
        <h1>SOIL</h1>
        <h5>As green as it gets</h5>
      </div>
    );
  
}
// Export the footer
export default Footer